from django.contrib import admin
from django import forms
from django.forms import ValidationError
from ..models import Page
from ..abstract.admin import AbstractBaseMPTTAdmin, BaseTranslationAdmin, BasePageAdmin, AdminFormFieldMixin
from mptt.admin import DraggableMPTTAdmin
from ..utils.check_sites import check_sites


class SitesForm(forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        if not check_sites(cleaned_data):
            raise ValidationError('Child element must have at least 1 same site as parent sites')
        return cleaned_data


@admin.register(Page)
class PageAdmin(BaseTranslationAdmin, BasePageAdmin, DraggableMPTTAdmin):
    form = SitesForm
    actions = AbstractBaseMPTTAdmin.actions
    list_display = (
        'tree_actions',
        'indented_title',
        'page_type',
        'is_active',
        'slug',
        'get_sites',
        'get_absolute_url',
    )
    list_display_links = (
        'indented_title',
        'page_type',
    )
    readonly_fields = (
        'get_absolute_url',
    )
    save_on_top = True
    prepopulated_fields = {'slug': ('title',)}
    list_filter = ('is_active', 'created_at',)
    search_fields = ('title', 'content')


