from django.db import models


class LoginRequaredMixin(models.Model):
    login_required = models.BooleanField(default=False, verbose_name='Требовать атворизацию для просмотра?')
    
    class Meta:
        abstract = True
