from ckeditor_uploader.fields import RichTextUploadingField
from django.utils.functional import cached_property
from django.db import models
from django.utils import translation
from django.conf import settings
from django.utils.module_loading import import_string
from django.contrib.sites.models import Site
from django.contrib.sites.managers import CurrentSiteManager


class GCurrentSiteManager(CurrentSiteManager):
    use_in_migrations = False

class AbstractBasePageModel(models.Model):
    """
    Базовая страница, на основе которой создаются все прочие страницы.
    """
    title = models.CharField(max_length=255, verbose_name='Название')
    is_active = models.BooleanField(default=True, verbose_name='Включено')
    slug = models.SlugField(max_length=150, verbose_name='ЧПУ', blank=True, default='')
    sites = models.ManyToManyField(Site, verbose_name='Сайты для отображения', default=settings.SITE_ID)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Дата изменения')
    seo_title = models.CharField(max_length=250, verbose_name='SEO заголовок страницы (title)', blank=True, default='')
    seo_keywords = models.CharField(max_length=250, verbose_name='SEO ключевые слова (keywords)', blank=True, default='')
    seo_description = models.CharField(max_length=250, verbose_name='SEO описание (description)', blank=True, default='')
    seo_author = models.CharField(max_length=250, verbose_name='SEO автор (author)', blank=True, default='')
    seo_og_type = models.CharField(max_length=250, verbose_name='SEO og:type', blank=True, default="website")
    content = RichTextUploadingField(verbose_name='Содержимое', blank=True, default='')

    objects = models.Manager()
    on_site = GCurrentSiteManager()


    class Meta:
        verbose_name = 'Базовая страница'
        verbose_name_plural = 'Базовые страницы'
        ordering = ('created_at', 'title',)
        abstract = True

    def __str__(self):
        return self.title

    def get_verbose_model_name(self):
        return self._meta.verbose_name
    get_verbose_model_name.short_description = 'Название модели'

    def get_absolute_url(self):
        return self.absolute_url
    get_absolute_url.short_description = 'URL'

    @cached_property
    def absolute_url(self):
        current_language_code_url_prefix = translation.get_language()
        try:
            use_default_prefix = settings.USE_DEFAULT_LANGUAGE_PREFIX
        except:
            use_default_prefix = True
        if not use_default_prefix and current_language_code_url_prefix == settings.LANGUAGE_CODE:
            current_language_code_url_prefix = ''
        elif current_language_code_url_prefix is None:
            current_language_code_url_prefix = ''
        else:
            current_language_code_url_prefix = '/' + current_language_code_url_prefix

        if self.slug:
            obj = self
            url_arr = [self.slug]
            while obj.parent is not None:
                obj = obj.parent
                if obj.slug:
                    url_arr.insert(0, obj.slug)
            return "{}/{}".format(current_language_code_url_prefix, '/'.join(url_arr))
        return "{}".format(current_language_code_url_prefix) if len(current_language_code_url_prefix) > 1 else '/'

    absolute_url.short_description = 'URL'

    @cached_property
    def get_sites(self):
        res = 'n/a'
        if self.sites.all().count() > 0:
            res = ''
            for site in self.sites.all():
                res += f'{site.domain} '
        return res

    get_sites.short_description = 'Sites'

    @cached_property
    def template(self):
        return settings.PAGE_TYPES[self.page_type]['template']

    def get_context(self, request=None):
        context_function = import_string(settings.PAGE_TYPES[self.page_type]['context'])
        return context_function(request)

    @classmethod
    def is_for_page_view(cls):
        return True
