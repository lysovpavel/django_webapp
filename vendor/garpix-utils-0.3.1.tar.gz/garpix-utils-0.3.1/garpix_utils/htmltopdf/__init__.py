import pdfkit


def str_to_pdf(html_str, output_filepath, options={}):
    options['quiet'] = ''
    pdfkit.from_string(html_str, output_filepath, options=options)
    return True
