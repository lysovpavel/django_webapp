import requests


def get_yt_info(id, api_key=None):
    """
    Функция получения мета данных видео размещенных на youtube.com в открытом доступе
    :param id: str - id видео сервиса youtube.com (https://www.youtube.com/watch?v=3LyJCdl14k8 : 3LyJCdl14k8 - id)
    :param api_key: str - ключь API для сервисов Google
    :return: dict - словарь с параметрами видео
    """
    if not api_key:
        from django.conf import settings
        if not hasattr(settings, 'GOOGLE_YOUTUBE_API_KEY'):
            return None
        api_key = settings.GOOGLE_YOUTUBE_API_KEY
    URL_MASK = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id={}&key={}'
    url = URL_MASK.format(id, api_key)
    resp = requests.get(url)
    return resp.json()


def get_cleaned_yt_info(id, api_key=None):
    """
    Функция получения данных видео размещенных на youtube.com в открытом доступе, а именно Название, Название канала,
    дату публикации, описание, превью(тамбнейлы), продолжительность видео.
    :param id: str - id видео сервиса youtube.com (https://www.youtube.com/watch?v=3LyJCdl14k8 : 3LyJCdl14k8 - id)
    :param api_key: str - ключь API для сервисов Google
    :return: dict - словарь с параметрами видео (ключи:'title', 'channelTitle', 'published', 'description', 'thumbnails'
    , 'duration')
    """
    if not api_key:
        from django.conf import settings
        if not hasattr(settings, 'GOOGLE_YOUTUBE_API_KEY'):
            return None
        api_key = settings.GOOGLE_YOUTUBE_API_KEY
    _data = get_yt_info(id, api_key)
    data = _data['items'][0]
    result = {
        'title': data['snippet']['title'],
        'channelTitle': data['snippet']['channelTitle'],
        'published': data['snippet']['publishedAt'],
        'description': data['snippet']['description'],
        'thumbnails': data['snippet']['thumbnails'],
        'duration': data['contentDetails']['duration'],
    }
    return result
