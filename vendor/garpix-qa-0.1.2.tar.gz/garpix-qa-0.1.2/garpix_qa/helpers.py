import sys
from .colors import *
import os
import subprocess


def print_default(text=''):
    sys.stdout.write(RESET)
    sys.stdout.write(f'  {text}')


def print_ok():
    sys.stdout.write(GREEN)
    sys.stdout.write(f' OK\n')


def print_error():
    sys.stdout.write(RED)
    sys.stdout.write(f' ERROR\n')


def print_header(text=''):
    sys.stdout.write(RESET)
    sys.stdout.write(BOLD)
    sys.stdout.write(f'\n{text}\n\n')


def print_empty():
    sys.stdout.write('\n')


def exists_file(path):
    error_count = 0
    print_default(f'Проверка наличия файла: {path}')

    if os.path.isfile(path):
        print_ok()
    else:
        print_error()
        error_count += 1
    return error_count


def exists_dir(path):
    error_count = 0
    print_default(f'Проверка наличия директории: {path}')

    if os.path.isdir(path):
        print_ok()
    else:
        print_error()
        error_count += 1
    return error_count


def shell_run(cmd):
    ps = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    lines = ps.communicate()[0]
    lines = lines.decode("utf-8")
    return lines
