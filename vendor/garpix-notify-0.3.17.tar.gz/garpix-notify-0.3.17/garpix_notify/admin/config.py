from django.contrib import admin
from solo.admin import SingletonModelAdmin
from ..models.config import NotifyConfig


@admin.register(NotifyConfig)
class NotifyConfigAdmin(SingletonModelAdmin):
    fieldsets = (
        (None, {
            'fields': ('periodic', 'is_email_enabled', 'is_sms_enabled', 'is_push_enabled')
        }),
        ('Почта', {
            'fields': ('email_max_day_limit', 'email_max_hour_limit')
        }),
        ('СМС', {
            'fields': ('sms_url', 'sms_api_id', 'sms_from')
        })
    )
