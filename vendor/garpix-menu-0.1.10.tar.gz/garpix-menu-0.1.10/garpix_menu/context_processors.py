"""
Контекстный процессор для меню.
"""
from django.conf import settings
from garpix_menu.models import MenuItem


def menu_processor(request):
    """
    Контекстный процессор для возможности отображения всех меню на сайте.
    Меню обычно распологаются на нескольких страницах, поэтому вынесено сюда.
    """
    current_path = request.get_full_path()
    context = {
        'menus': {}
    }
    for menu_type_arr in settings.CHOICE_MENU_TYPES:
        context['menus'][menu_type_arr[0]] = MenuItem.objects.filter(is_active=True, menu_type=menu_type_arr[0], parent=None).order_by('sort')
        for menu_item in context['menus'][menu_type_arr[0]]:
            if menu_item.get_link() == current_path:
                menu_item.is_current = True
                menu_item.is_current_full = True
            elif current_path.startswith(menu_item.get_link()):
                menu_item.is_current = True
            elif menu_item.url and menu_item.url.endswith(current_path):
                menu_item.is_current = True
    return context
