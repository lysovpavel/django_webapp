from django.apps import AppConfig


class GarpixMenuConfig(AppConfig):
    name = 'garpix_menu'
