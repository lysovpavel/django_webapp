def slug_validation(model, cleaned_data):
    result = True
    if cleaned_data.get('title', None):
        for child in model.objects.filter(parent=cleaned_data['parent']).exclude(
                title=cleaned_data['title']):
            if cleaned_data['slug'] == child.slug:
                result = False
    if cleaned_data.get('title_ru', None):
        for child in model.objects.filter(parent=cleaned_data['parent']).exclude(
                title_ru=cleaned_data['title_ru']):
            if cleaned_data['slug'] == child.slug:
                result = False
    return result
