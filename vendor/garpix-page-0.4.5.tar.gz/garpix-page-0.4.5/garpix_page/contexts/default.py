def context(request, *args, **kwargs):
    return {}
