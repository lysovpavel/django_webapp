from django.conf import settings
from django.http import Http404
from django.shortcuts import get_object_or_404
from garpix_page.models import Page
import django.apps
from django.utils import translation
from django.contrib.sites.models import Site


model_list = []
for model in django.apps.apps.get_models():
    try:
        if model.is_for_page_view():
            model_list.append(model)
    except:  # noqa
        pass


class PageMixin:
    def get_template_names(self):
        """
        Метод для получения темплейта для страницы.
        Структуру темплейтов можно посмотреть в модели page.models.Page.
        """
        return [self.object.template]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(self.object.get_context(self.request, object=self.object))
        return context

    def get_object(self, queryset=None):
        """
        Метод для получения объекта страницы.
        Сравнивает текущий урл со slug, которые мы получаем из родительских страниц нашей страницы.
        """
        current_language_code_url_prefix = translation.get_language()
        try:
            use_default_prefix = settings.USE_DEFAULT_LANGUAGE_PREFIX
        except:  # noqa
            use_default_prefix = True
        if not use_default_prefix and current_language_code_url_prefix == settings.LANGUAGE_CODE:
            current_language_code_url_prefix = ''
        elif current_language_code_url_prefix is None:
            current_language_code_url_prefix = ''
        else:
            current_language_code_url_prefix = '/' + current_language_code_url_prefix

        home_page = get_object_or_404(Page.on_site.filter(page_type__in=settings.HOME_PAGES, is_active=True)[:1])

        url = self.kwargs.get('url', None)
        if not url:
            return home_page
        obj_list = []
        slugs = url.rstrip('/').split('/')
        slug = slugs[-1]
        parent_slug = slugs[-2] if len(slugs) > 2 else None
        for model in model_list:
            if parent_slug:
                _obj = model.on_site.filter(slug=slug, parent__slug=parent_slug).first()
            else:
                _obj = model.on_site.filter(slug=slug).first()
            if _obj:
                obj_list.append(_obj)
        obj = None
        for item in obj_list:
            if item.get_absolute_url() == f'{current_language_code_url_prefix}/{url}':
                obj = item
                break
        if not obj:
            raise Http404
        if not obj.is_active:
            raise Http404
        return obj
