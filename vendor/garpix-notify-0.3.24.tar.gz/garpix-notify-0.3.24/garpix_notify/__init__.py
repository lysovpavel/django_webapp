default_app_config = 'garpix_notify.apps.NotifyConfig'
