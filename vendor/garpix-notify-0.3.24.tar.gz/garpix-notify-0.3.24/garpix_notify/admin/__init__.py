from .category import NotifyCategoryAdmin
from .config import NotifyConfigAdmin
from .notify import NotifyAdmin
from .smtp import SMTPAccountAdmin
from .fcm import NotifyDeviceAdmin
from .template import NotifyTemplateAdmin
from .file import NotifyFileAdmin
from .user_list import NotifyUserListAdmin
