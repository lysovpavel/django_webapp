from django.apps import AppConfig


class NotifyConfig(AppConfig):
    name = 'garpix_notify'
    verbose_name = 'Уведомления'
