from rest_framework import mixins, status
from rest_framework import permissions
from rest_framework import viewsets
from .models import Notify
from .models.choices import TYPE
from .serializers import NotifySerializer
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from rest_framework.decorators import list_route


User = get_user_model()


class PushNotifyViewSet(mixins.RetrieveModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    permission_classes = [permissions.IsAuthenticated]
    queryset = Notify.objects.filter(type=TYPE.PUSH)
    serializer_class = NotifySerializer

    def get_queryset(self):
        queryset = Notify.objects.filter(type=TYPE.PUSH)
        if self.request.user is not None and self.request.user.is_authenticated:
            queryset = queryset.filter(user=self.request.user)
            return queryset.order_by('-created_at')
        return Notify.objects.none()

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())

        page = self.paginate_queryset(queryset)
        if page is not None:
            serializer = self.get_serializer(page, many=True)
            data = serializer.data
            for obj in page:
                obj.is_read = True
                obj.save()
            return self.get_paginated_response(data)

        serializer = self.get_serializer(queryset, many=True)
        data = serializer.data
        for obj in queryset:
            obj.is_read = True
            obj.save()
        return Response(data)

    @list_route(methods=['post'])
    def mark_read(self, request):
        """
        Отметить сообщения как прочитанные.
        """
        if request.user.is_authenticated:
            user = User.objects.get(pk=request.user.pk)
            str_ids = request.data.get('ids', '')
            ids = [int(x) for x in str_ids.split(',')]
            for id in ids:
                try:
                    notify = Notify.objects.get(type=TYPE.PUSH, user=user, id=id)
                    notify.is_read = True
                    notify.save()
                except:  # noqa
                    pass
            return Response({'status': True})
        return Response({'status': False}, status=status.HTTP_400_BAD_REQUEST)

    @list_route(methods=['post'])
    def mark_read_all(self, request):
        """
        Отметить сообщения как прочитанные.
        """
        if request.user.is_authenticated:
            user = User.objects.get(pk=request.user.pk)
            for notify in Notify.objects.filter(type=TYPE.PUSH, user=user):
                try:
                    notify.is_read = True
                    notify.save()
                except:  # noqa
                    pass
            return Response({'status': True})
        return Response({'status': False}, status=status.HTTP_400_BAD_REQUEST)
