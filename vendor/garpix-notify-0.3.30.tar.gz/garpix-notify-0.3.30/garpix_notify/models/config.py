from django.db import models
from solo.models import SingletonModel


class NotifyConfig(SingletonModel):
    periodic = models.IntegerField(default=60, verbose_name='Периодичность отправки уведомлений (сек.)')

    email_max_day_limit = models.IntegerField(default=240, verbose_name='Дневной лимит отправки писем')
    email_max_hour_limit = models.IntegerField(default=40, verbose_name='Часовой лимит отправки писем')

    sms_url = models.CharField(default='http://sms.ru/sms/send', max_length=255, verbose_name='URL СМС провайдера')
    sms_api_id = models.CharField(default='1234567890', blank=True, max_length=255, verbose_name='API ID СМС провайдера')
    sms_from = models.CharField(default='', blank=True, max_length=255, verbose_name='Отправитель СМС', help_text='Например, Garpix')

    is_email_enabled = models.BooleanField(default=True, verbose_name='Разрешить отправку Email')
    is_sms_enabled = models.BooleanField(default=True, verbose_name='Разрешить отправку SMS')
    is_push_enabled = models.BooleanField(default=True, verbose_name='Разрешить отправку PUSH')

    class Meta:
        verbose_name = 'Настройка'
        verbose_name_plural = 'Настройки'
