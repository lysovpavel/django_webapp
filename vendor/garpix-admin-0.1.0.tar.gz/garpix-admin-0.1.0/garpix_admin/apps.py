from django.apps import AppConfig


class AdminConfig(AppConfig):
    name = 'garpix_admin'
    verbose_name = 'Административная панель'
