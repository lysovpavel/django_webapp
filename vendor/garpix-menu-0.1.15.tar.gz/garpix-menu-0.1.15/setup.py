from setuptools import setup, find_packages
import sys

setup(
    name='garpix-menu',
    version='0.1.15',
    description='Garpix menu package',
    author='Garpix LTD',
    author_email='info@garpix.com',
    license='Commercial',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: Commercial',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Framework :: Django',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7'
    ],
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        'Django >= 2.0',
        'django-mptt >= 0.9.1',
        'django-modeltranslation >= 0.13b1',
        'garpix_page >= 0.1.0'
    ],
)
