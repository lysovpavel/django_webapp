default_app_config = 'garpix_menu.apps.GarpixMenuConfig'
