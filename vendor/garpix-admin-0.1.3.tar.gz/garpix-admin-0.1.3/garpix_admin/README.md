# Использование
Для форсированного отображения панели на лист вью в класс админки небоходимо добавить параметр ```side_bar_on = True```
Для добавления кастомных форм на change_list_view (admin site) модели необходимо пеорпеделить блок custom_list шаблона change_list.html
    Классы:
        "list-group-item" - для всех полей 
        "list-group-item active" - для выделения поля как активного (цвет фона - синий, цвет текста - белый)
        "text" - для всех span элементов
        "submit-row list-group" - для form 
```
{% extends 'admin/change_list.html' %}
{% block custom_list %}
    <form class="submit-row list-group">
      <label class="list-group-item active">label</label>
      <input  class="list-group-item " placeholder="Текстовое поле">
      <input type="text" class="list-group-item " placeholder="Текстовое поле">
      <input type="text" class="list-group-item " placeholder="Текстовое поле">
      <button type="submit" class="list-group-item"  name="index">Button</button>
    </form>
{% endblock %}

```

Для добавления кастомных форм в на change_view (admin site) инстанса необходимо пеорпеделить блок custom_form шаблона change_form.html
Конструкция:
```
{% extends 'admin/change_form.html' %}
{% block custom_form %}
    <div class="submit-row list-group">
        ...
    </div>
{% endblock %}
```
создает новый блок, в который необходимо поместить поля формы.
    Классы:
        "list-group-item" - для всех полей 
        "list-group-item active" - для выделения поля как активного (цвет фона - синий, цвет текста - белый)
        "text" - для всех span элементов

# Список изменений

0.1.3
- Вынесены inline в отдельные вкладки.
- Добавлен процессинг fieldsets

0.1.1 (27.06.2019)

- Перевод админ. панели

0.1.0 (14.02.2019)

- Добавлены файлы для сборки
- Сделан билд версии 0.1.0
- Добавлена возможность отображения ссылки на изменение инстанса для инлайнов (show_change_link=True)

ALPHA (без версии) (08.02.2019)

- Логотип изменен на Garpix
- Скопирован модуль https://github.com/douglasmiranda/django-admin-bootstrap (версия 0.4.0, лицензия MIT)
