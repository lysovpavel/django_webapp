default_app_config = 'garpix_admin.apps.AdminConfig'
