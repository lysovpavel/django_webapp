from rest_framework import routers, serializers, viewsets, mixins, status
from .models import Notify


class NotifySerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Notify
        fields = ('id', 'subject', 'text', 'created_at', 'data_json', 'is_read')
