from django.test import TestCase
from .signature import make_signature_sha512


class SignatureTestCase(TestCase):
    def setUp(self):
        self.params = {
            'a': 'xxx',
            'c': 'ggg',
            'b': '111',
            'sig': '2123086085ec1fe67595d7b3d2b6a0dbf3f33e528d78366b8d62d7f0a7e3c090077b0f7b8dc84921a6087aa57b8284bd1e74702df7a16e96f73f627e6eea815a',
            'd': [3, 1, 2],
            'e': {
                'b': '2',
                'a': '1'
            }
        }
        self.secret = 'secret'
        super().setUp()

    def test_signature_positive(self):
        income_signature = self.params['sig']
        our_signature = make_signature_sha512(self.params, 'sig', self.secret)
        self.assertEqual(income_signature, our_signature)

    def test_with_not_exists_signature(self):
        del self.params['sig']
        our_signature = make_signature_sha512(self.params, 'sig', self.secret)
        self.assertNotEqual(None, our_signature)

    def test_with_empty_signature(self):
        self.params['sig'] = None
        income_signature = self.params['sig']
        our_signature = make_signature_sha512(self.params, 'sig', self.secret)
        self.assertNotEqual(income_signature, our_signature)
