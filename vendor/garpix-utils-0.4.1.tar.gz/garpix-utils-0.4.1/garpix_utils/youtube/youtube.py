import requests


def get_youtube_id(value):
    """
    Вырезает ID из ссылки на видео.
    Examples:
    - http://youtu.be/SA2iWivDJiE
    - http://www.youtube.com/watch?v=_oPAwA_Udwc&feature=feedu
    - http://www.youtube.com/embed/SA2iWivDJiE
    - http://www.youtube.com/v/SA2iWivDJiE?version=3&amp;hl=en_US
    """
    from urllib.parse import urlparse
    from urllib.parse import parse_qs
    query = urlparse(value)
    if query.hostname == 'youtu.be':
        return query.path[1:]
    if query.hostname in ('www.youtube.com', 'youtube.com'):
        if query.path == '/watch':
            p = parse_qs(query.query)
            return p['v'][0]
        if query.path[:7] == '/embed/':
            return query.path.split('/')[2]
        if query.path[:3] == '/v/':
            return query.path.split('/')[2]
    return None


def get_youtube_thumbnail(youtube_id):
    """
    Возвращает миниатюру для видео с Youtube.
    :param youtube_id:
    :return:
    """
    return 'https://img.youtube.com/vi/{youtube_id}/mqdefault.jpg'.format(youtube_id=youtube_id)


def get_yt_info(id, api_key=None):
    """
    Функция получения мета данных видео размещенных на youtube.com в открытом доступе
    :param id: str - id видео сервиса youtube.com (https://www.youtube.com/watch?v=3LyJCdl14k8 : 3LyJCdl14k8 - id)
    :param api_key: str - ключь API для сервисов Google
    :return: dict - словарь с параметрами видео
    """
    if not api_key:
        from django.conf import settings
        if not hasattr(settings, 'GOOGLE_YOUTUBE_API_KEY'):
            return None
        api_key = settings.GOOGLE_YOUTUBE_API_KEY
    URL_MASK = 'https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id={}&key={}'
    url = URL_MASK.format(id, api_key)
    resp = requests.get(url)
    return resp.json()


def get_cleaned_yt_info(id, api_key=None):
    """
    Функция получения данных видео размещенных на youtube.com в открытом доступе, а именно Название, Название канала,
    дату публикации, описание, превью(тамбнейлы), продолжительность видео.
    :param id: str - id видео сервиса youtube.com (https://www.youtube.com/watch?v=3LyJCdl14k8 : 3LyJCdl14k8 - id)
    :param api_key: str - ключь API для сервисов Google
    :return: dict - словарь с параметрами видео (ключи:'title', 'channelTitle', 'published', 'description', 'thumbnails'
    , 'duration')
    """
    if not api_key:
        from django.conf import settings
        if not hasattr(settings, 'GOOGLE_YOUTUBE_API_KEY'):
            return None
        api_key = settings.GOOGLE_YOUTUBE_API_KEY
    _data = get_yt_info(id, api_key)
    data = _data['items'][0]
    result = {
        'title': data['snippet']['title'],
        'channelTitle': data['snippet']['channelTitle'],
        'published': data['snippet']['publishedAt'],
        'description': data['snippet']['description'],
        'thumbnails': data['snippet']['thumbnails'],
        'duration': data['contentDetails']['duration'],
    }
    return result
