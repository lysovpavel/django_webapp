from django.core.management.base import BaseCommand, CommandError
from ...main import run


class Command(BaseCommand):
    help = 'QA tests for project.'

    def handle(self, *args, **options):
        run()
