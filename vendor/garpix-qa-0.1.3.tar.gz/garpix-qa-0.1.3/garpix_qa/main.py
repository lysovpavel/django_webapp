from django.conf import settings
import os
from .helpers import print_header
from .helpers import print_default
from .helpers import exists_file
from .helpers import exists_dir
from .helpers import shell_run
from .helpers import print_error
from .helpers import print_ok
from .helpers import print_empty
import datetime


def run():
    DIR = os.path.abspath(os.path.join(settings.BASE_DIR, '..'))
    #
    error_count = 0
    start_at = datetime.datetime.now()
    #
    print_header('Входные данные')
    print_default(f'Директория: {DIR}\n')
    print_default(f'Начало проверки: {start_at}\n')

    # CHECK CI
    print_header('Проверка CI')
    error_count += exists_file(os.path.join(DIR, '.gitlab-ci.yml'))
    error_count += exists_file(os.path.join(DIR, 'example.env'))
    error_count += exists_file(os.path.join(DIR, 'Dockerfile'))

    # *** CHECK BACKEND ***
    print_header('Проверка бэкенда')
    error_count += exists_dir(os.path.join(DIR, 'backend'))

    # flake8 for backend
    print_default('Проверка на соответствие стандарту PEP8')
    backend_dir = os.path.join(DIR, 'backend')
    cmd = f'flake8 {backend_dir} --exclude=.git,__pycache__,old,build,dist,venv,*/migrations/*,*/settings/* --ignore=E501,F401'
    lines = shell_run(cmd)
    if lines != '':
        lines = lines.split('\n')
        print_error()
        for line in lines:
            print_default(f'{line}\n')
        error_count += len(lines)
    else:
        print_ok()

    # unit tests
    print_default('Юнит-тесты')
    path = os.path.join(DIR, 'backend')
    cmd = f'cd {path};python manage.py test -k'
    lines = shell_run(cmd)
    if 'OK' in lines:
        print_ok()
    else:
        print_error()
        print(lines)

    # *** CHECK FRONTEND ***
    print_header('Проверка фронтенда')
    error_count += exists_dir(os.path.join(DIR, 'frontend'))
    # error_count += exists_file(os.path.join(DIR, 'frontend', 'Dockerfile'))

    # *** CHECK DEPLOY ***
    print_header('Проверка деплоя')
    error_count += exists_dir(os.path.join(DIR, 'deploy'))
    # error_count += exists_dir(os.path.join(DIR, 'deploy', 'images'))
    # error_count += exists_dir(os.path.join(DIR, 'deploy', 'servers'))

    # *** RESULT ***
    end_at = datetime.datetime.now()
    duration = end_at - start_at

    print_header('Результат')
    print_default(f'Количество ошибок: {error_count}\n')
    print_default(f'Окончание проверки: {end_at}\n')
    print_default(f'Длительность проверки: {duration}\n')
    print_empty()
