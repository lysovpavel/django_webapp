# -------------------------------------------------
# - Хелперы для объектов ``models.FileFields()`` -
# -------------------------------------------------
import datetime
import uuslug
import random
import string
import os
from django.conf import settings


def get_random_string(size=8, chars=string.ascii_uppercase + string.digits):
    """
    Получает случайную строку указанного размера и с указанными символами.
    """
    return ''.join(random.SystemRandom().choice(chars) for _ in range(size))


def get_file_path(instance, filename):
    """
    Формирует путь файла относительно года и месяца, чтобы множество файлов не скапливались на одном уровне.
    """
    ext = filename.split('.')[-1]
    today = datetime.date.today()
    filename = "%s.%s" % (uuslug.slugify(".".join(filename.split('.')[:-1])), ext)
    return 'uploads/%s/%s/%s' % (today.year, today.month, filename)


def get_secret_path(instance, filename):
    today = datetime.date.today()
    subdir1 = get_random_string(16)
    subdir2 = get_random_string(16)
    subdir3 = get_random_string(16)
    ext = filename.split('.')[-1]
    filename = "%s.%s" % (uuslug.slugify(".".join(filename.split('.')[:-1])), ext)
    path = 'data/%s/%s/%s/%s/%s' % (today.year, today.month, subdir1, subdir2, subdir3)

    os.makedirs(os.path.join(settings.MEDIA_ROOT, path))
    return os.path.join(path, filename)
