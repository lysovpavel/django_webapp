добавить в settings reclaim.py (аналогично page.py)
в контекст к странице добавить:
```
from garpix_reclaim.models import Reclaim
from app.settings.reclaim import *
def context(request, *args, **kwargs):
    type_list = [список типов рекламы из settings.reclaim]
    reclaim = Reclaim.get_reclaim(request, type_list)
    Reclaim.add_view(reclaim)
    return {'reclaim': reclaim}
```

# Список изменений

0.1.03 (16.01.2020)
- Возможность добавления файлов

0.1.04 (17.01.2020)
- Валидация файлов ('jpeg', 'jpg', 'png', 'mp4')
