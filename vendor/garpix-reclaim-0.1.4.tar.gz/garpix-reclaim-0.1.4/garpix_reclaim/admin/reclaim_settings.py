from django.contrib import admin
from solo.admin import SingletonModelAdmin
from ..models.reclaim_settings import ReclaimSettings


@admin.register(ReclaimSettings)
class ReclaimSettingsAdmin(SingletonModelAdmin):
    pass
