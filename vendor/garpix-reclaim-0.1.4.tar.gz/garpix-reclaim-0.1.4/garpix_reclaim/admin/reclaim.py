from django.contrib import admin
from garpix_reclaim.models.reclaim import Reclaim


@admin.register(Reclaim)
class ReclaimAdmin(admin.ModelAdmin):
    list_display = ['__str__', 'is_active', 'show_count', 'max_show_count', 'reclaim_type']
    list_editable = ['is_active', 'max_show_count', 'reclaim_type']
    readonly_fields = ['show_count', ]
