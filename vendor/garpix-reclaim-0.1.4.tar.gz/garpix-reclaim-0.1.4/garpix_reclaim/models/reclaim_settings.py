from django.db import models
from solo.models import SingletonModel
from garpix_page.models import Page


class ReclaimSettings(SingletonModel):

    is_show = models.BooleanField(default=True, verbose_name='Показывать рекламу')
    pages = models.ManyToManyField(Page, blank=True, verbose_name='Страницы для отображения рекламы')

    def __str__(self):
        return 'Настройка показа рекламы'

    class Meta:
        verbose_name = 'Настройка показа рекламы'
