from django.db import models
from garpix_utils.file_field.file_field import get_file_path
from .reclaim_settings import ReclaimSettings
from django.db.models import F
from django.conf import settings
from django.utils.module_loading import import_string
from django.core.validators import FileExtensionValidator


class CustomQuerySet(models.QuerySet):
    pass

class CustomReclaim(models.Manager):
    def get_queryset(self):
        return CustomQuerySet(self.model, using=self._db).annotate(left_show_count=F('max_show_count')-F('show_count'))

class Reclaim(models.Model):

    title = models.CharField(max_length=500, default='', blank=True, null=True, verbose_name='Название')
    is_active = models.BooleanField(default=True, verbose_name='Отображать рекламу')
    image = models.FileField(upload_to=get_file_path, null=True, blank=True, verbose_name='Изображение',
                             validators=[FileExtensionValidator(allowed_extensions=['jpeg', 'jpg', 'png', 'mp4'])])
    link = models.CharField(max_length=500, default='', verbose_name='Ссылка', blank=True)
    reclaim_type = models.IntegerField(default=1, verbose_name='Тип рекламы', choices=settings.CHOICES_RECLAIM_TYPES)
    max_show_count = models.PositiveIntegerField(default=0, verbose_name='Максимальное число показов')
    show_count = models.PositiveIntegerField(default=0, verbose_name='Число показов')

    objects = CustomReclaim()

    def __str__(self):
        if self.title:
            return self.title
        return f'reclaim_{self.id}'

    def add_view(data):
        for type in data:
            for item in data[type]:
                item.show_count += 1
                if item.max_show_count != 0:
                    if item.left_show_count < 2:
                        item.is_active = False
                item.save()

    def get_reclaim(request, type_list):
        import random
        random.seed(version=2)
        reclaim_dict = {}
        for type in settings.RECLAIM_TYPES:
            if type in type_list:
                reclaims = list(Reclaim.objects.filter(reclaim_type=type, is_active=True))
                title = settings.RECLAIM_TYPES[type]['title']
                count = settings.RECLAIM_TYPES[type]['count']
                if len(reclaims) > count:
                    reclaim_list_by_type = []
                    for item in range(0, count):
                        reclaim = random.choice(reclaims)
                        reclaim_list_by_type.append(reclaim)
                        reclaims.remove(reclaim)
                else:
                    reclaim_list_by_type = reclaims
                reclaim_dict[title] = reclaim_list_by_type
        return reclaim_dict

    def get_reclaim_all(request):
        return Reclaim.objects.filter(is_active=True).order_by('-id')

    def get_reclaim_blocked(request):
        return Reclaim.objects.filter(is_active=False).order_by('-id')

    def get_reclaim_full(request):
        return Reclaim.objects.all().order_by('-is_active', '-id')

    class Meta:
        verbose_name = 'Реклама'
        verbose_name_plural = 'Реклама'
