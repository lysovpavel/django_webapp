from django.apps import AppConfig


class GarpixReclaimConfig(AppConfig):
    name = 'garpix_reclaim'
    verbose_name = 'Реклама'
