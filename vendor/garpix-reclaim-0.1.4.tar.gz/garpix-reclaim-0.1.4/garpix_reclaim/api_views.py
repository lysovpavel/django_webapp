from rest_framework.views import APIView
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import viewsets
from .models import Reclaim
from .serializers import ReclaimSerializer


class ReclaimAPIViewSet(viewsets.ModelViewSet):

    def get_queryset(self):
        qs = Reclaim.objects.all()
        return qs

    @action(detail=True, methods=['get'])
    def get_reclaim(self, request):
        try:
            qs = Reclaim.get_reclaim(request)
            data = {}
            for item in qs:
                data[item] = ReclaimSerializer(qs[item], many=True).data
            Reclaim.add_view(qs)
            return Response({'status': True, 'Случайно выбранная реклама': data})
        except Exception as e:
            print({'status': False, 'Error': str(e)})
            return Response({'status': False, 'Error': str(e)})

    # @action(detail=True, methods=['get'])
    # def get_reclaim_all(self, request):
    #     try:
    #         qs = Reclaim.get_reclaim_all(request)
    #         data = ReclaimSerializer(qs, many=True).data
    #         return Response({'status': True, 'Вся активная реклама': data})
    #     except Exception as e:
    #         return Response({'status': False, 'Error': str(e)})
    #
    # @action(detail=True, methods=['get'])
    # def get_reclaim_blocked(self, request):
    #     try:
    #         qs = Reclaim.get_reclaim_blocked(request)
    #         data = ReclaimSerializer(qs, many=True).data
    #         return Response({'status': True, 'Вся заблокированная реклавма': data})
    #     except Exception as e:
    #         return Response({'status': False, 'Error': str(e)})
    #
    # @action(detail=True, methods=['get'])
    # def get_reclaim_full(self, request):
    #     try:
    #         qs = Reclaim.get_reclaim_full(request)
    #         data = ReclaimSerializer(qs, many=True).data
    #         return Response({'status': True, 'Полный список рекламы': data})
    #     except Exception as e:
    #         return Response({'status': False, 'Error': str(e)})
