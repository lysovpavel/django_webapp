from rest_framework import serializers
from ..models.reclaim import Reclaim


class ReclaimSerializer(serializers.ModelSerializer):

    class Meta:
        model = Reclaim
        fields = (
            '__str__',
            'id',
            'title',
            'is_active',
            'image',
            'link',
            'max_show_count',
            'show_count',
        )
