from django.urls import path
from .api_views import ReclaimAPIViewSet


urlpatterns = [
    path('get_reclaim/', ReclaimAPIViewSet.as_view({'get': 'get_reclaim'}), name='get_reclaim'),
    # path('get_reclaim_all/', ReclaimAPIViewSet.as_view({'get': 'get_reclaim_all'}), name='get_reclaim_all'),
    # path('get_reclaim_blocked/', ReclaimAPIViewSet.as_view({'get': 'get_reclaim_blocked'}), name='get_reclaim_blocked'),
    # path('get_reclaim_full/', ReclaimAPIViewSet.as_view({'get': 'get_reclaim_full'}), name='get_reclaim_full'),
]
