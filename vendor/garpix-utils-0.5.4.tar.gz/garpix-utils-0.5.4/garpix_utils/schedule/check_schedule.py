"""
Функция, которая возвращает True, если переданные данные выполняются в переданную дату,
либо False во всех иных случаях.

    second - запускать в определенную секунду, целое число от 0 до 59
    minute - запускать в определенную минуту, целое число от 0 до 59
    hour - запускать в определенный час, целое число от 0 до 23
    day - запускать в опеределенный день, целое число от 1 до 31 и от -1 до -31
    week_day - запускать в опеделенный день недели, целое число от 1 до 7
    month - запускать в определенный месяц, целое число от 1 до 11
    year - запускать в определенный год, целое число от 2019 до 2029

    every_... - может быть только один
    every_second - запускать каждую секунду с указанным интервалом, целое число от 1 до 59
    every_minute - запускать каждую минуту с указанным интервалом, целое число от 1 до 59
    every_hour - запускать каждый час с указанным интервалом, целое число от 1 до 23
    every_day - запускать каждый день с указанным интервалом, целок число от 1 до 30
    every_month - запускать каждый месяц с указанным интервалом, целое число от 1 до 11
    every_year - запускать каждый год с указанным интервалом, целое число от 1 до 29

# testing
python manage.py test garpix_utils.tests -k
"""
from django.utils import timezone
import calendar
# dates = timezone.now()
# max_day_in_months = calendar.monthrange(dates.year, dates.month)[1]
SCHEDULE_LIMIT_RANGES = {
    'second': {
        'min': 0,
        'max': 59
    },
    'minute': {
        'min': 0,
        'max': 59
    },
    'hour': {
        'min': 0,
        'max': 23
    },
    'day': {
        'min': 0,
        'max': 31
    },
    'week_day': {
        'min': 1,
        'max': 7
    },
    'month': {
        'min': 1,
        'max': 11
    },
    'year': {
        'min': 2019,
        'max': 2029
    },
}
SCHEDULE_LIMIT_EVERY_RANGES = {
    'second': {
        'min': 0,
        'max': 59,
    },
    'minute': {
        'min': 0,
        'max': 59,
    },
    'hour': {
        'min': 0,
        'max': 23,
    },
    'day': {
        'min': 0,
        'max': 30,
    },
    'month': {
        'min': 0,
        'max': 11,
    },
    'year': {
        'min': 0,
        'max': 29,
    },
}
SCHEDULE_AVAILABLE_EVERY_KEYS = ['every_second', 'every_minute', 'every_hour',
                                 'every_day', 'every_month', 'every_year']
SCHEDULE_KEYS_FOR_EVERY = ['second', 'minute', 'hour', 'day', 'month', 'year']


def check_schedule(date=None, *args, **kwargs):
    # Если все None, то ничего не делаем
    param_list = list(kwargs.values())
    found = False
    for param in param_list:
        if param is not None:
            found = True
            break
    if not found:
        return False
    # Если дату не передали, то берем текущую
    if date is None:
        date = timezone.now()
    # every
    every = None
    every_key = None
    for key in SCHEDULE_AVAILABLE_EVERY_KEYS:
        if key in kwargs:
            if every is None:
                every = kwargs[key]
                every_key = key.split('_')[1]  # second, minute, ...
            else:
                return False  # every задан два раза
    if every is not None:
        value = getattr(date, every_key, 0)
        if every < SCHEDULE_LIMIT_EVERY_RANGES[every_key]['min'] or every > SCHEDULE_LIMIT_EVERY_RANGES[every_key]['max']:
            return False
        if value % every != 0:
            return False
        # Если задан евери и не проставлены предыдущие значения (например, для каждого часа
        # это будет минуты = 0 и секунды = 0, для каждого дня - часы, минуты, секунды = 0
        every_key_index = SCHEDULE_KEYS_FOR_EVERY.index(every_key)
        for index, key in enumerate(SCHEDULE_KEYS_FOR_EVERY):
            if index < every_key_index:
                if key in ['day', 'month']:
                    kwargs[key] = 1
                else:
                    kwargs[key] = 0
    # Если хотя бы одно условие не выполнилось, то возвращаем False
    for key in SCHEDULE_KEYS_FOR_EVERY:
        if key in kwargs and kwargs[key] is not None and key != 'day':
            if kwargs[key] < SCHEDULE_LIMIT_RANGES[key]['min'] \
               or kwargs[key] > SCHEDULE_LIMIT_RANGES[key]['max'] \
               or getattr(date, key) != kwargs[key]:
                return False
    # Получаем кол-во дней в текущем месяце
    day = kwargs['day'] if 'day' in kwargs else None
    max_day_in_month = calendar.monthrange(date.year, date.month)[1]
    if day is not None and (day < 0):
        day += 1 + max_day_in_month
    if day is not None and (day < SCHEDULE_LIMIT_RANGES['day']['min'] or day > max_day_in_month or date.day != day):
        return False
    # Дни недели
    week_day = kwargs['week_day'] if 'week_day' in kwargs else None
    if week_day is not None and (week_day < SCHEDULE_LIMIT_RANGES['week_day']['min'] or  # noqa
                                 week_day > SCHEDULE_LIMIT_RANGES['week_day']['max'] or  # noqa
                                 (date.weekday()+1) != week_day):  # noqa
        return False
    return True
