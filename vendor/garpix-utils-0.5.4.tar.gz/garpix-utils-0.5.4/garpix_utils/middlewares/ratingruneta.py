class AwardRatingrunetaMiddleware:
    """
    Добавьте в миддлвары следующую строку
    MIDDLEWARE = [
        # ...
        'garpix_utils.middlewares.ratingruneta.AwardRatingrunetaMiddleware',
    ]
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response['X-Frame-Options'] = "ALLOW-FROM awards.ratingruneta.ru"
        return response
