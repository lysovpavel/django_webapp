# Функция преобразования контекста в ссылку


def http_build_query(params, topkey=''):
    from urllib.parse import quote

    if len(params) == 0:
        return ""

    result = ""

    if type(params) is dict:
        for key in params.keys():
            newkey = quote(key)
            if topkey != '':
                newkey = topkey + quote('[' + key + ']')

            if type(params[key]) is dict:
                result += http_build_query(params[key], newkey)

            elif type(params[key]) is list:
                i = 0
                for val in params[key]:
                    result += newkey + quote('[' + str(i) + ']') + "=" + quote(str(val)) + "&"
                    i = i + 1

            # логическое значение должно также иметь особое отношение
            elif type(params[key]) is bool:
                result += newkey + "=" + quote(str(int(params[key]))) + "&"

            # предположить строку (целые числа и числа с плавающей точкой работают хорошо)
            else:
                result += newkey + "=" + quote(str(params[key])) + "&"

    # удаляет последний '&'
    if (result) and (topkey == '') and (result[-1] == '&'):
        result = result[:-1]

    return result
