from django.utils.timezone import now
from pytz import timezone as tz
import pytz
from django.conf import settings
from tzlocal import get_localzone


def as_django_datetime(date):
    system_tz = get_localzone()

    django_tz = tz(settings.TIME_ZONE) if hasattr(settings, 'TIME_ZONE') else system_tz

    if hasattr(settings, 'USE_TZ') and settings.USE_TZ:
        return date.astimezone(django_tz)
    else:
        _date = pytz.timezone(system_tz.tzname(dt=None)).localize(date, is_dst=None)
        if system_tz != django_tz:
            return _date.astimezone(django_tz.tzname(dt=None)).replace(tzinfo=None)
        return _date.replace(tzinfo=None)


def local_now():
    return as_django_datetime(now())
