from os.path import exists
from tempfile import NamedTemporaryFile
import os
try:
    from shutil import which
except ImportError:
    from distutils.spawn import find_executable
    which = find_executable

PANDOC_PATH = which('pandoc')


def convert_to_file(content, output_filename, suffix=".html", arguments=[]):
    if PANDOC_PATH is None:
        raise Exception('Pandoc is not installed yet. Install it first.')
    temp_file = NamedTemporaryFile(mode="w", suffix=suffix, delete=False)
    temp_file.write(content)
    temp_file.close()

    subprocess_arguments = [PANDOC_PATH, temp_file.name, '-o %s' % output_filename]
    subprocess_arguments.extend(arguments)
    cmd = " ".join(subprocess_arguments)

    fin = os.popen(cmd)
    msg = fin.read()
    fin.close()
    if msg:
        print("Pandoc message: {}".format(msg))

    os.remove(temp_file.name)

    if exists(output_filename):
        return output_filename
    else:
        raise IOError("Failed creating file: %s" % output_filename)
