from django.test import TestCase
from garpix_utils.schedule import check_schedule
from django.utils import timezone
from datetime import timedelta


class ScheduleTestCase(TestCase):
    def setUp(self):
        self.positive_schedule_second = {
            'second': 0,
        }
        self.negative_schedule_second = {
            'second': -1,
        }
        self.positive_schedule_minute = {
            'minute': 1,
        }
        self.negative_schedule_minute = {
            'minute': -1,
        }
        self.positive_schedule_hour = {
            'hour': 1,
        }
        self.negative_schedule_hour = {
            'hour': -1,
        }
        self.positive_schedule_day = {
            'day': 28,
        }
        self.positive_schedule_day_false = {
            'day': 45,
        }
        self.negative_schedule_day = {
            'day': -3,
        }
        self.positive_schedule_week = {
            'week_day': 4,
        }
        self.positive_schedule_month = {
            'month': 6,
        }
        self.negative_schedule_month = {
            'month': 7,
        }
        self.positive_schedule_year = {
            'year': 2019,
        }
        self.negative_schedule_year = {
            'year': 2325,
        }
        self.negative_schedule_week = {
            'week_day': 4,
        }
        # every_... test
        self.positive_every_multiple = {
            'every_second': 1,
            'every_minute': 1,
        }
        self.negative_every_multiples = {
            'every_second': 3,
        }
        self.negative_every_false_multiple = {
            'every_hour': 25,
        }
        self.negative_schedule_multi = {
            'every_day': 1
        }
        self.negative_none_schedule = {
            'day': None
        }
        self.positive_schedule_multiple_month = {
            'every_year': 1
        }

        super().setUp()

    def test_notify_email_positive(self):
        #
        date = timezone.now().replace(second=0)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_second), True)
        #
        date = timezone.now().replace(second=1)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_second), False)
        #
        date = timezone.now().replace(minute=1)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_minute), True)
        #
        date = timezone.now().replace(minute=1)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_minute), False)
        #
        date = timezone.now().replace(hour=1)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_hour), True)
        #
        date = timezone.now().replace(hour=1)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_hour), False)
        #
        date = timezone.now().replace(day=28, month=6, year=2019)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_day), True)
        #
        date = timezone.now().replace(day=28, month=6, year=2019)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_day_false), False)
        #
        date = timezone.now().replace(day=28, month=6, year=2019)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_day), True)
        #
        date = timezone.now().replace(day=6, month=6, year=2019)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_week), True)
        #
        date = timezone.now().replace(day=5, month=6, year=2019)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_week), False)
        #
        date = timezone.now().replace(month=6)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_month), True)
        #
        date = timezone.now().replace(month=6)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_month), False)
        #
        date = timezone.now().replace(year=2019)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_year), True)
        #
        date = timezone.now().replace(year=2019)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_year), False)
        #
        date = timezone.now()
        self.assertEqual(check_schedule(date=date, **self.positive_every_multiple), False)
        #
        date = timezone.now().replace(second=5)
        self.assertEqual(check_schedule(date=date, **self.negative_every_multiples), False)
        #
        date = timezone.now().replace(hour=5)
        self.assertEqual(check_schedule(date=date, **self.negative_every_false_multiple), False)
        #
        self.assertEqual(check_schedule(**self.positive_every_multiple), False)
        #
        date = timezone.now().replace(day=5)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_multi), False)
        #
        date = timezone.now().replace(day=5, second=0, minute=0, hour=0)
        self.assertEqual(check_schedule(date=date, **self.negative_schedule_multi), True)
        #
        date = timezone.now().replace(day=4)
        self.assertEqual(check_schedule(date=date, **self.negative_none_schedule), False)
        #
        date = timezone.now().replace(second=0, minute=0, hour=0, day=1, month=1, year=2025)
        self.assertEqual(check_schedule(date=date, **self.positive_schedule_multiple_month), True)
