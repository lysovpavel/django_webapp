from rest_framework.serializers import ModelSerializer
from ..models import Component, ComponentChildren


class ComponentSerializer(ModelSerializer):

    class Meta:
        model = Component
        fields = '__all__'


class ComponentChildrenSerializer(ModelSerializer):

    class Meta:
        model = ComponentChildren
        fields = '__all__'
