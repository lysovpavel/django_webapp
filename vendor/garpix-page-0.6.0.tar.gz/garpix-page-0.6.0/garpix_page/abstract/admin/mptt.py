from mptt.admin import MPTTModelAdmin, TreeRelatedFieldListFilter


class AbstractBaseMPTTAdmin(MPTTModelAdmin):
    """
    Абстрактная модель для древовидной структуры.
    """
    actions = ('rebuild',)
    list_filter = ('parent', TreeRelatedFieldListFilter)

    def _rebuild(self):
        try:
            self.model.objects.rebuild()
        except:  # noqa
            print('[ERROR]: Ошибка при перезагрузки древовидной структуры')

    def rebuild(self, request, queryset):
        """Пересорбать МПТТ модель. Иногда требуется для перезагрузки дерева."""
        self._rebuild()
    rebuild.short_description = 'Пересобрать пункты раздела'

    def save_model(self, request, obj, form, change):
        # пересобрать МПТТ объекты
        self._rebuild()
        super(AbstractBaseMPTTAdmin, self).save_model(request, obj, form, change)

    class Meta:
        abstract = True
