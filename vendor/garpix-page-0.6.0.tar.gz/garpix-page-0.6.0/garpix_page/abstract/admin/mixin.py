from contextlib import suppress
from django import forms


class AdminFormFieldMixin:
    def get_form(self, *args, **kwargs):
        form = super().get_form(*args, **kwargs)

        for field in form.base_fields.values():
            if isinstance(field, forms.CharField):
                with suppress(Exception):
                    field.widget.attrs = {**{'style': 'width: 80%;'}, **field.widget.attrs}

        return form
