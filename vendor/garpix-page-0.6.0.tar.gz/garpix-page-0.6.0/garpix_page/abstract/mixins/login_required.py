from django.db import models


class LoginRequiredMixin(models.Model):
    login_required = models.BooleanField(default=False, verbose_name='Требовать авторизацию для просмотра?')

    class Meta:
        abstract = True
