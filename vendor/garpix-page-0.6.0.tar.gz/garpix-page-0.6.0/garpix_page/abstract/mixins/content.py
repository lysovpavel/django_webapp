from django.utils import timezone
from ckeditor_uploader.fields import RichTextUploadingField
from django.db import models
from django.utils.functional import cached_property


class TitleMixin(models.Model):
    title = models.CharField(max_length=255, verbose_name='Название')

    class Meta:
        abstract = True

    def __str__(self):
        return self.title


class TitleSlugMixin(models.Model):
    title = models.CharField(max_length=255, verbose_name='Название')
    slug = models.SlugField(max_length=150, verbose_name='ЧПУ', blank=True, default='', unique=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.title

    @cached_property
    def absolute_url(self):
        return self.slug if self.slug == '/' else f'{self.slug}'


class TimeStampMixin(models.Model):
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    updated_at = models.DateTimeField(auto_now=True, verbose_name='Дата изменения')

    class Meta:
        abstract = True


class SEOMixin(models.Model):
    seo_title = models.CharField(max_length=250, verbose_name='SEO заголовок страницы (title)', blank=True, default='')
    seo_keywords = models.CharField(max_length=250, verbose_name='SEO ключевые слова (keywords)', blank=True,
                                    default='')
    seo_description = models.CharField(max_length=250, verbose_name='SEO описание (description)', blank=True,
                                       default='')
    seo_author = models.CharField(max_length=250, verbose_name='SEO автор (author)', blank=True, default='')
    seo_og_type = models.CharField(max_length=250, verbose_name='SEO og:type', blank=True, default="website")

    class Meta:
        abstract = True


class ActiveMixin(models.Model):
    is_active = models.BooleanField(default=True, verbose_name='Включено')

    class Meta:
        abstract = True


class ContentMixin(models.Model):
    content = RichTextUploadingField(verbose_name='Содержимое', blank=True, default='')

    class Meta:
        abstract = True


class ContentAsTextMixin(models.Model):
    content = models.TextField(verbose_name='Содержимое', blank=True, default='')

    class Meta:
        abstract = True


class PubDateMixin(models.Model):
    pub_date = models.DateTimeField(default=timezone.now, verbose_name='Дата публикации')

    class Meta:
        abstract = True
