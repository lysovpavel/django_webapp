from django.shortcuts import redirect
from django.views.generic import DetailView
from ..abstract.views.page import PageMixin
from ..utils.check_redirect import check_redirect
from django.conf import settings


class PageView(PageMixin, DetailView):
    """
    Детальная вьюшка для просмотра любых страниц.
    Для того, чтобы изменить темплейт или контекст - смотрите настройки app/settings.py.
    """
    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        if getattr(self.object, 'login_required', None):
            if not self.request.user.is_authenticated:
                return redirect(settings.LOGIN_URL)
        context = self.get_context_data(object=self.object)
        redir = check_redirect(request, context)
        if redir:
            return redirect(redir)
        return self.render_to_response(context)

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        if getattr(self.object, 'login_required', None):
            if not self.request.user.is_authenticated:
                return redirect(settings.LOGIN_URL)
        context = self.get_context_data(object=self.object)
        redir = check_redirect(request, context)
        if redir:
            return redirect(redir)
        return self.render_to_response(context)
