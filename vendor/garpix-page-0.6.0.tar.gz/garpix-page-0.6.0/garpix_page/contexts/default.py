from garpix_reclaim.models import Reclaim
from app.settings.reclaim import *


def context(request, *args, **kwargs):
    type_list = [RECLAIM_TYPE_VERTICAL, RECLAIM_TYPE_DIAGONAL, RECLAIM_TYPE_HORIZONTAL]
    reclaim = Reclaim.get_reclaim(request, type_list)
    Reclaim.add_view(reclaim)
    return {'reclaim': reclaim}
