from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.viewsets import ModelViewSet
from ..models import Component, ComponentChildren
from ..serializers import ComponentSerializer, ComponentChildrenSerializer
from ..permissions import IsAdminOrReadOnly


class ComponentViewSet(ModelViewSet):
    queryset = Component.objects.all()
    serializer_class = ComponentSerializer
    permission_classes = [IsAdminOrReadOnly, ]
    filter_backends = (DjangoFilterBackend, )
    filter_fields = {
        'title': ['icontains', ],
    }


class ComponentChildrenViewSet(ModelViewSet):
    queryset = ComponentChildren.objects.all()
    serializer_class = ComponentChildrenSerializer
    permission_classes = [IsAdminOrReadOnly, ]
    filter_backends = (DjangoFilterBackend, )
    filter_fields = {
        'title': ['icontains', ],
    }
