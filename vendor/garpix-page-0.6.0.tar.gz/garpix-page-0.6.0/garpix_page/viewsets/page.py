from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.viewsets import ModelViewSet
from ..models import Page
from ..serializers import PageSerializer
from ..permissions import IsAdminOrReadOnly


class PageViewSet(ModelViewSet):
    queryset = Page.objects.all()
    serializer_class = PageSerializer
    permission_classes = [IsAdminOrReadOnly, ]
    filter_backends = (DjangoFilterBackend, )
    filter_fields = {
        'title': ['icontains', ],
        'page_type': ['exact', ],
        'slug': ['exact', ],
    }
