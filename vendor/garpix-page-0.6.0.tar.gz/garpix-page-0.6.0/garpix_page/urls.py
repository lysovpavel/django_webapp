from rest_framework.routers import DefaultRouter
from . import viewsets

router = DefaultRouter()

router.register(r'component', viewsets.ComponentViewSet)
router.register(r'component_children', viewsets.ComponentChildrenViewSet)
router.register(r'page', viewsets.PageViewSet)

urlpatterns = router.urls
