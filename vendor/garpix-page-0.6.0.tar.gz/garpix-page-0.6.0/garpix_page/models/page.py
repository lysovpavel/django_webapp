from django.db import models
from ..abstract.models.abstract_page import AbstractBasePageModel
from ..abstract.mixins.login_required import LoginRequiredMixin
from django.conf import settings
from mptt.models import MPTTModel, TreeForeignKey
from ..utils.check_sites import check_sites


class Page(LoginRequiredMixin, AbstractBasePageModel, MPTTModel):
    parent = TreeForeignKey('self', null=True, blank=True, related_name='children', db_index=True,
                            verbose_name='Родительская страница', on_delete=models.SET_NULL,
                            limit_choices_to={'page_type__gt': 1})
    page_type = models.IntegerField(default=2, verbose_name='Тип страницы', choices=settings.CHOICES_PAGE_TYPES)

    def get_components(self):
        return self.component_set.filter(is_active=True).all()

    def get_components_dict(self):
        result = {}
        for item in self.component_set.filter(is_active=True).all():
            if item.position not in result:
                result[item.position] = []
            result[item.position].append(item)
        return result

    class Meta:
        verbose_name = "Страница"
        verbose_name_plural = "Страницы"
        ordering = ('-created_at',)
