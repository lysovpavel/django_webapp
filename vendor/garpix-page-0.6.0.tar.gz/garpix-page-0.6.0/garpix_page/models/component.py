from django.db import models
from django.conf import settings
from .page import Page
from ckeditor_uploader.fields import RichTextUploadingField
from garpix_page.utils.get_file_path import get_file_path


class Component(models.Model):
    position = models.CharField(default='', max_length=100, choices=settings.CHOICES_COMPONENT_POSITION, verbose_name='Позиция')
    template = models.CharField(default='', max_length=100, choices=settings.CHOICES_COMPONENT_TEMPLATE, verbose_name='Шаблон')
    page = models.ForeignKey(Page, null=True, blank=True, verbose_name='Страница', on_delete=models.CASCADE)

    title = models.CharField(max_length=255, default='', verbose_name='Название')
    is_active = models.BooleanField(default=True, verbose_name='Включено')
    content = RichTextUploadingField(blank=True, default='', verbose_name='Содержимое')
    image = models.FileField(upload_to=get_file_path, blank=True, null=True, verbose_name='Изображение')
    sort = models.IntegerField(default=100, verbose_name='Сортировка', help_text='Чем меньше число, тем выше будет элемент в списке.')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Компонент"
        verbose_name_plural = "Компонент"
        ordering = ('sort',)


class ComponentChildren(models.Model):
    title = models.CharField(max_length=255, default='', null=True, blank=True, verbose_name='Название')
    content = RichTextUploadingField(default="", null=True, blank=True, verbose_name="Текст")
    component = models.ForeignKey(Component, verbose_name='Компонент', on_delete=models.CASCADE)
    image = models.FileField(verbose_name='Изображение', blank=True, null=True, upload_to=get_file_path)
    sort = models.IntegerField(default=100, verbose_name='Сортировка', help_text='Чем меньше число, тем выше будет элемент в списке.')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "Дочерний компонент"
        verbose_name_plural = "Дочерний компонент"
        ordering = ('sort',)
