def slug_validation(model, cleaned_data, instance):
    result = True
    if instance.id:
        if cleaned_data.get('title', None):
            for child in model.objects.filter(parent=cleaned_data['parent']).exclude(pk=instance.id):
                if cleaned_data['slug'] == child.slug:
                    result = False
        if cleaned_data.get('title_ru', None):
            for child in model.objects.filter(parent=cleaned_data['parent']).exclude(pk=instance.id):
                if cleaned_data['slug'] == child.slug:
                    result = False
    else:
        if cleaned_data.get('title', None):
            for child in model.objects.filter(parent=cleaned_data['parent']).all():
                if cleaned_data['slug'] == child.slug:
                    result = False
        if cleaned_data.get('title_ru', None):
            for child in model.objects.filter(parent=cleaned_data['parent']).all():
                if cleaned_data['slug'] == child.slug:
                    result = False
    return result
