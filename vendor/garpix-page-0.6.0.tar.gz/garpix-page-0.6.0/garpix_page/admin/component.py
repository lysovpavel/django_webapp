from ..models import Component, ComponentChildren
from ..abstract.admin import BaseTranslationAdmin
from django.contrib import admin
from nested_admin.nested import NestedTabularInline, NestedModelAdmin, NestedStackedInline
from modeltranslation.admin import TranslationAdmin, TranslationTabularInline, TranslationStackedInline


class ComponentChildrenInline(NestedTabularInline, TranslationStackedInline):
    model = ComponentChildren


@admin.register(Component)
class ComponentAdmin(BaseTranslationAdmin, NestedModelAdmin):
    inlines = [
        ComponentChildrenInline
    ]


@admin.register(ComponentChildren)
class ComponentChildrenAdmin(BaseTranslationAdmin, NestedModelAdmin):
    pass
