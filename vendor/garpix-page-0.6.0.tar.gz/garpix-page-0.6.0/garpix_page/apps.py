from django.apps import AppConfig


class GarpixPageConfig(AppConfig):
    name = 'garpix_page'
    verbose_name = 'Страницы'
