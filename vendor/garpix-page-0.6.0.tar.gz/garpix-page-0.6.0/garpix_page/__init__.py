default_app_config = 'garpix_page.apps.GarpixPageConfig'
