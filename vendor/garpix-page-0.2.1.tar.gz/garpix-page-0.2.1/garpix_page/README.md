# Модуль Страниц Django

Предоставляет класс Page для создания страниц сайта.
Предоставляет абстрактный класс AbstractBasePageModel для создания кастомных моделей, которые используют
представлениие PageView.

## Установка

1. Указываем пакет в `garpix_core` в `INSTALLED_APPS`
2. Устанавливаем миграции
3. Создать шаблоны страниц
4. Создать функии определения контекста страниц
5. В settings укакзать типы страниц проекта:
```
PAGE_TYPE_HOME = 1
PAGE_TYPE_DEFAULT = 2

PAGE_TYPES = {
    PAGE_TYPE_HOME: {
            'title': 'Главная страница',
            'template': 'pages/home.html',                     # Указать путь до шаблона главной страницы
            'context': 'garpix_core.contexts.home.context'     # Указать путь до функции определения контекста страницы
    },
    PAGE_TYPE_DEFAULT: {
            'title': 'Обычная',
            'template': 'pages/default.html',                  # Указать путь до шаблона простой страницы (по умолчанию)
            'context': 'garpix_core.contexts.default.context'  # Указать путь до функции определения контекста страницы
    },
}
CHOICES_PAGE_TYPES = [(k, v['title']) for k, v in PAGE_TYPES.items()]
```
   Для добавления специфичных типов страниц в словарь PAGE_TYPES добавить необходимое количество элементов:
```
PAGE_TYPE_XXX = X
PAGE_TYPES = {
    ...
    PAGE_TYPE_XXX: {
            'title': 'Название типа',
            'template': 'путь.до.шаблона.html',         # Указать путь до шаблона простой страницы (по умолчанию)
            'context': 'путь.до.контекстной.функции'    # Указать путь до функции определения контекста страницы
    },
}

```
   Так же необходимо добавить параметры для ckeditor:
```
CKEDITOR_UPLOAD_PATH = ''

CKEDITOR_CONFIGS = {
    'default': {
        'toolbar': 'full',
        'width': '100%',
    },
}
```
   И определить повдение get_absolute_url() для языка по умолчанию (использовать языковой префикс или нет).
   Если не указать даный параметр то по умолчанию get_absolute_url() будет возвращать URL с префиксом ('/ru/some_page/') 
```
USE_DEFAULT_LANGUAGE_PREFIX = True
```  
6. в urls проекта добавить:
```
from django.urls import include, path, re_path
from django.conf.urls.i18n import i18n_patterns
from multiurl import ContinueResolving, multiurl
from garpix_page.views.page import PageView

urlpatterns += [
    path('ckeditor/', include('ckeditor_uploader.urls')),
]

urlpatterns += i18n_patterns(
    multiurl(
        path('', PageView.as_view()),
        re_path(r'^(?P<url>.*?)$', PageView.as_view(), name='page'),
        re_path(r'^(?P<url>.*?)/$', PageView.as_view(), name='page'),
        catch=(Http404, ContinueResolving),
    ),
    prefix_default_language=settings.USE_DEFAULT_LANGUAGE_PREFIX,
)
```
## Использование:

Переопределить контекстные функции для типов страниц Главная и Обычная, добавить новые функции в соответствии с проектом,
 затем указать в settings.PAGE_TYPES.
Для добавления кастомных моделей (Новость, Запись Блога) нужно создать модель, унаследовавшись от AbstractBasePageModel.
Определить поле parent (родитель) типа ForeignKey с указанием в качестве родителя:
  - Page (для добавления 'списочного' типа страниц). При этом рекомендуется в методе self.save() жестко привязать
  инстанс Page нужного типа (например: для новостей - страницу Новости);
  - 'self' если не надо зависеть от адресов (slug) объектов Page;
Если соображениями проекта для отображения кастомных страниц необходимо испольовать специальный класс/функцию для оторбражения
(views) то в кастомной модели необхдимо переоделить метод is_for_page_view() что бы результат функции возвращал False.
Так же, если нет необходимости обеспечивтаь связь меджду объектами кастомной модели (parent-child) то так же неопходимо
 переопредилить метод is_for_page_view() -> False.

## Примеры

### Создание кастомной модели
project/app/models/news.py
```
from garpix_page.abstract.models.abstract_page import AbstractBasePageModel
from garpix_page.models.page import Page
from django.conf import settings

class News(AbstractBasePageModel):
    parent = models.ForeignKey(
        Page, models.DO_NOTHING, related_name='children_news',
        blank=True, null=True,
        verbose_name='Родительская страница'
    )
    is_popular = models.BooleanField(verbose_name='Отображать в популярном?', default=False)

    class Meta:
        verbose_name = 'Новость'
        verbose_name_plural = 'Новости'
        ordering = ['-created_at',]

    def save(self, *args, **kwargs):
        self.parent = Page.objects.filter(page_type=settings.PAGE_TYPE_NEWS).first()
        super(News, self).save()
```

### Создание кастомной модели без привязки к Page, переопределением is_for_page_view()
project/app/models/news.py
```
from garpix_page.abstract.models.abstract_page import AbstractBasePageModel
from garpix_page.models.page import Page
from django.conf import settings

class Blog(AbstractBasePageModel):
    is_popular = models.BooleanField(verbose_name='Отображать в популярном?', default=False)

    class Meta:
        verbose_name = 'Запись блога'
        verbose_name_plural = 'Записи блога'
        ordering = ['-created_at',]

    @classmethod
    def is_for_page_view(self):
        return False
```

### Создание контекстной функции
project/app/contexts/home.py
```
def context(request):
    from app.models import News
    return {
        'banner_text': 'Some banner text',
        'news': News.objects.all()[:10]
    }
```
project/app/settings.py
```
PAGE_TYPES = {
    PAGE_TYPE_HOME: {
            'title': 'Главная',
            'template': 'pages/default.html',
            'context': 'app.contexts.home.context'
    },
    ...
}
```
