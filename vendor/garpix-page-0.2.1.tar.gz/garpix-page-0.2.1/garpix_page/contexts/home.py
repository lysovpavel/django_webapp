def context(request):
    return {}
