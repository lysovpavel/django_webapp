from modeltranslation.translator import TranslationOptions, register
from ..models import Component, ComponentChildren
from django.contrib import admin


@register(Component)
class ComponentTranslationOptions(TranslationOptions):
    fields = ('title', 'content',)


@register(ComponentChildren)
class ComponentChildrenTranslationOptions(TranslationOptions):
    fields = ('title', 'content',)
