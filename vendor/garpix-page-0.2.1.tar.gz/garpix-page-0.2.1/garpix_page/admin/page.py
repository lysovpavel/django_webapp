from django.contrib import admin
from ..models import Page
from ..abstract.admin import AbstractBaseMPTTAdmin, BaseTranslationAdmin, BasePageAdmin, AdminFormFieldMixin
from mptt.admin import DraggableMPTTAdmin
# from ..admin.mixin import AdminFormFieldMixin

@admin.register(Page)
class PageAdmin(BaseTranslationAdmin, BasePageAdmin, DraggableMPTTAdmin):
    pass


# class PageAdmin(AdminFormFieldMixin, DraggableMPTTAdmin, BaseTranslationAdmin, AbstractBaseMPTTAdmin):
    actions = AbstractBaseMPTTAdmin.actions
    list_display = (
        'tree_actions',
        'indented_title',
        'page_type',
        'is_active',
        'slug',
        'get_absolute_url',
    )
    list_display_links = (
        'indented_title',
        'page_type',
    )
    readonly_fields = (
        'get_absolute_url',
    )
    save_on_top = True
    prepopulated_fields = {'slug': ('title',)}

    # inlines = [
    #     MediaTabularInline,
    #     # PhotoInline,
    #     # YoutubeVideoInline,
    # ]
    list_filter = ('is_active', 'created_at',)
    search_fields = ('title', 'content')
