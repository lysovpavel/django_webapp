from .page import PageAdmin
from .component import ComponentAdmin, ComponentChildrenAdmin