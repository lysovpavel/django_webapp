from simple_history.admin import SimpleHistoryAdmin


class BaseAdmin(SimpleHistoryAdmin):
    empty_value_display = '- нет -'
    save_on_top = True
    view_on_site = True
