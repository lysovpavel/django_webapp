from modeltranslation.admin import TabbedTranslationAdmin
from .base import BaseAdmin


class BaseTranslationAdmin(BaseAdmin, TabbedTranslationAdmin):
    save_on_top = True
    empty_value_display = '- нет -'
    view_on_site = True
