from .base import BaseAdmin


class BasePageAdmin(BaseAdmin):
    """
    Стандартные настройки для базовых страниц.
    """
    date_hierarchy = 'created_at'
    prepopulated_fields = {'slug': ('title',)}

    search_fields = ('title',)
    list_filter = ('is_active', 'created_at', 'updated_at')
    actions = ('clone_object',)

    list_display = ('title', 'created_at', 'is_active', 'get_absolute_url',)
    list_editable = ('is_active',)

    readonly_fields = ('created_at', 'updated_at')


    def clone_object(self, request, queryset):
        """Копирование(клонирование) выбранных объектов - action"""
        for obj in queryset:
            prefix = '-_CLONE'
            clone = obj
            clone.title += prefix
            clone.slug += prefix
            clone.seo_title = clone.seo_description = clone.seo_keywords = ''
            clone.id = None
            clone.is_active = False
            clone.save()
    clone_object.short_description = 'Клонировать объект'

